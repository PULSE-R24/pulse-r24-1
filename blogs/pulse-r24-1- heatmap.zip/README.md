# PULSE-R24 Heatmap Fix Package

## What Was Fixed
The map originally referenced CARTO dark basemaps (`basemaps.cartocdn.com`), which started enforcing paid authentication and stamped the **"API KEY REQUIRED"** watermark across the entire India map.

This package replaces the tile server with **OpenStreetMap** (100% Free, zero authentication, no API keys needed) and adds a CSS dark theme invert filter to preserve the dark aesthetic.

## How To Install Into Your Repository

1. Copy `PulseMap.jsx` into your React repository:
   - Place into: `src/components/PulseMap.jsx` (or replace your current `HeroMap.jsx` / `PublicHome.jsx` map section)

2. Copy the CSS rules from `pulse-map.css` into your main stylesheet:
   - Paste into: `src/index.css` or `src/App.css`

3. Make sure dependencies are installed in your project:
   ```bash
   npm install leaflet react-leaflet leaflet.heat
   ```

4. Build or push your repository:
   ```bash
   git add .
   git commit -m "fix(map): switch basemap to OpenStreetMap to resolve API key watermark"
   git push origin main
   ```
